<footer class="bg-dark text-center text-white ">
    <div class="container d-flex justify-content-between">
        <div class="text-center p-3">
            © 2022 Copyright <span>version: {{\Tremby\LaravelGitVersion\GitVersionHelper::getVersion()}}</span>
        </div>
        <div class="text-center p-3">
            Created by: <strong>Facundo Massa</strong>
        </div>
    </div>
</footer>
