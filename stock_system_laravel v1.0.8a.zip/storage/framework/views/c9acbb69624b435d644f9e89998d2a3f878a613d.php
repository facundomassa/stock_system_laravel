

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(Session::has('mensaje')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">

                <strong><?php echo e(Session::get('mensaje')); ?></strong>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <table class="table table-striped table-hover table-md" id="movement-t">
            <thead>
                <tr>
                    <th class="table-light">#</th>
                    <th class="table-light">Codigo</th>
                    <th class="table-light">Nombre</th>
                    <th class="table-light">Unidad</th>
                    <th class="table-light">Tipo</th>
                    <th class="table-light">Cantidad</th>
                </tr>
            </thead>
            <tbody>
                <?php if(isset($movements)): ?>
                    <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($movement->id_article->id); ?></td>
                            <td><?php echo e($movement->id_article->code); ?></td>
                            <td><?php echo e($movement->id_article->name); ?></td>
                            <td><?php echo e($movement->id_article->unit); ?></td>
                            <td><?php echo e($movement->id_article->type); ?></td>
                            <td><?php echo e($movement->quantity); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
        <?php if($refer->status == 'I'): ?>
            <a class="btn btn-primary me-2" href="<?php echo e(url('refer/' . $refer->id . '/edit')); ?>">Emitir</a>
        <?php endif; ?>
        <?php if($refer->status == 'I' || $refer->status == 'E'): ?>
            <a class="btn btn-warning me-2" href="<?php echo e(url('movement/create/' . $refer->id )); ?>">Editar</a>
            <form class="d-inline" action="<?php echo e(url('/refer/finalized/' . $refer->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PATCH')); ?>

                <input class="btn btn-success me-2" type="submit" onclick="return confirm('¿Finalizar remito?')"
                    value="Finalizar">
            </form>
            <form class="d-inline" action="<?php echo e(url('/refer/' . $refer->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

                <input class="btn btn-danger me-2" type="submit" onclick="return confirm('¿Cancelar remito?')" value="Cancelar">
            </form>
        <?php endif; ?>
        <a class="btn btn-primary" href="<?php echo e(url('refer/' . $refer->id)); ?>">Regresar</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views/movement/show.blade.php ENDPATH**/ ?>