<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="form-group">
    <label for="origen_id_stockcenter">Origen:</label>
    <select required class="form-control" name="origen_id_stockcenter" id="origen_id_stockcenter">
        <option disabled selected value="">-Seleccionar una opcion-</option>
        <?php $__currentLoopData = $stockcenters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stockcenter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if((isset($refer->origen_id_stockcenter) ? $refer->origen_id_stockcenter : old('origen_id_stockcenter')) == $stockcenter->id): ?>
                <option selected value="<?php echo e($stockcenter->id); ?>"> <?php echo e($stockcenter->name); ?></option>
            <?php else: ?>
                <option value="<?php echo e($stockcenter->id); ?>"> <?php echo e($stockcenter->name); ?></option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="form-group">
    <label for="destiny_id_stockcenter">Origen:</label>
    <select required class="form-control" name="destiny_id_stockcenter" id="destiny_id_stockcenter">
        <option disabled selected value="">-Seleccionar una opcion-</option>
        <?php $__currentLoopData = $stockcenters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stockcenter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if((isset($refer->destiny_id_stockcenter) ? $refer->destiny_id_stockcenter : old('destiny_id_stockcenter')) == $stockcenter->id): ?>
                <option selected value="<?php echo e($stockcenter->id); ?>"> <?php echo e($stockcenter->name); ?></option>
            <?php else: ?>
                <option value="<?php echo e($stockcenter->id); ?>"> <?php echo e($stockcenter->name); ?></option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="form-group">
    <label for="status">Estatus:</label>
    <P><?php echo e(isset($refer->statusName) ? $refer->statusName : "INGRESADO"); ?></P>
</div>
<div class="form-group">
    <label for="date_ended">Fecha Finalizado:</label>
    <input class="form-control" min="<?php echo e(date("Y-m-d") . "T" . date("h:i")); ?>" type="datetime-local" value="<?php echo e(isset($refer->date_ended) ? $refer->date_ended : old('date_ended')); ?>" name="date_ended" id="date_ended">
</div>
<div class="form-group">
    <label>Creado por:</label>
    <select disabled class="form-control" >
        <option selected value="<?php echo e(auth()->id()); ?>"> <?php echo e(auth()->user()->name . " " . auth()->user()->surname); ?></option>
    </select>
</div>
<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> Datos">
<a class="btn btn-primary" href="<?php echo e(url('refer/')); ?>">Regresar</a>
<?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\Refer\form.blade.php ENDPATH**/ ?>