

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('layouts/alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(url('/stock/')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('GET')); ?>

            <label for="sc">Centro de Stock:</label>
            <select required class="form-control" name="sc" maxlength="60" id="stockcenter" onchange="this.form.submit()">
                <option selected value="*">-Todos-</option>
                <?php $__currentLoopData = $stockcenters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stockcenter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($sc == $stockcenter->id): ?>
                        <option selected value="<?php echo e($stockcenter->id); ?>"> <?php echo e($stockcenter->name); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($stockcenter->id); ?>"> <?php echo e($stockcenter->name); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label for="ar">Articulo:</label>
            <input class="form-control" type="text" name="ar" maxlength="40"
                value="<?php echo e(isset($ar) ? $ar : old('ar')); ?>" id="ar" onchange="this.form.submit()">
        </form>
        <table class="table table-striped table-hover table-md">
            <thead>
                <tr>
                    <th class="table-light">#</th>
                    <th class="table-light">Centro de Stock</th>
                    <th class="table-light">Articulo</th>
                    <th class="table-light">Unidad</th>
                    <th class="table-light">Cantidad</th>
                    <th class="table-light">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($stock->id); ?></td>
                        <td><?php echo e($stock->StockCenter->name); ?></td>
                        <td><?php echo e($stock->Article->name); ?></td>
                        <td><?php echo e($stock->Article->UnitName); ?></td>
                        <td><?php echo e($stock->quantity); ?></td>
                        <td>
                            <a class="btn btn-outline-dark py-0" href="<?php echo e(url('/stock/' . $stock->id)); ?>"><i
                                    class="bi bi-eye-fill"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        <?php echo $stocks->links('vendor.pagination.bootstrap-5'); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\Stock\index.blade.php ENDPATH**/ ?>