<div class="container">

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <!-- Left Side Of Navbar -->
        <ul class="navbar-nav me-auto">
            <!-- Navigation -->
            <nav id="slide-menu">
                <ul>
                    <li><a href="<?php echo e(url('/article')); ?>">Articulos</a></li>
                    <li><a href="<?php echo e(url('/direction')); ?>">Direcciones</a></li>
                    <li><a href="<?php echo e(url('/enterprise')); ?>">Operaciones</a></li>
                    <li><a href="<?php echo e(url('/movement')); ?>">Movimientos</a></li>
                    <li><a href="<?php echo e(url('/permission')); ?>">Permisos</a></li>
                    <li><a href="<?php echo e(url('/person')); ?>">Personas</a></li>
                    <li><a href="<?php echo e(url('/refer')); ?>">Remitos</a></li>
                    <li><a href="<?php echo e(url('/stockcenter')); ?>">Centros de Stock</a></li>
                    <li><a href="<?php echo e(url('/stock')); ?>">Stock</a></li>
                </ul>
                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ms-auto buttom-zero">
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?>

                                <?php echo e(Auth::user()->surname); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-end bottom-top" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>

            <!-- Content panel -->

        </ul>


    </div>
</div>
<?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\layouts\navbar.blade.php ENDPATH**/ ?>