

<?php $__env->startSection('content'); ?>
    <div class="container">
        <p><?php echo e($direction->id); ?></p>
        <div class="form-group">
            <label for="country">Pais:</label>
            <p><?php echo e($direction->country); ?></p>
        </div>
        <div class="form-group">
            <label for="state">Provincia:</label>
            <p><?php echo e($direction->state); ?></p>
        </div>
        <div class="form-group">
            <label for="city">Ciudad:</label>
            <p><?php echo e($direction->city); ?></p>
        </div>
        <div class="form-group">
            <label for="locality">Localidad:</label>
            <p><?php echo e($direction->locality); ?></p>
        </div>
        <div class="form-group">
            <label for="street">Calle:</label>
            <p><?php echo e($direction->street); ?></p>
        </div>
        <div class="form-group">
            <label for="number">Numero:</label>
            <p><?php echo e($direction->number); ?></p>
        </div>
        <div class="form-group">
            <label for="department">Departamento:</label>
            <p><?php echo e($direction->department); ?></p>
        </div>
        <div class="form-group">
            <label for="house">Casa:</label>
            <p><?php echo e($direction->house); ?></p>
        </div>
        <div class="form-group">
            <label for="floor">Piso:</label>
            <p><?php echo e($direction->floor); ?></p>
        </div>
        <div class="form-group">
            <label for="cp">Codigo Postal:</label>
            <p><?php echo e($direction->cp); ?></p>
        </div>
        <div class="form-group">
            <label for="updated_at">Ultima Actualizacion:</label>
            <p><?php echo e($direction->updated_at); ?></p>
        </div>
        <br>
        <a class="btn btn-success" href="<?php echo e(url('direction/' . $direction->id . '/edit')); ?>">Editar</a>
        <a class="btn btn-primary" href="<?php echo e(url('direction/')); ?>">Regresar</a>
        <form class="d-inline" action="<?php echo e(url('/direction/' . $direction->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

            <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')"
                value="Borrar">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\direction\show.blade.php ENDPATH**/ ?>