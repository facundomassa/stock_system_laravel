<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<input type="hidden" name="id_refer" value="<?php echo e($id_refer); ?>">
<table class="table table-striped table-hover table-md" id="movement-t">
    <thead>
        <tr>
            <th class="table-light">#</th>
            <th class="table-light">Codigo</th>
            <th class="table-light">Nombre</th>
            <th class="table-light">Unidad</th>
            <th class="table-light">Tipo</th>
            <th class="table-light">Cantidad</th>
            <th class="table-light">En Stock</th>
            <th class="table-light text-center">Eliminar</th>
        </tr>
    </thead>
    <tbody>
        <?php if(isset($movements)): ?>
            <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($movement->id_article->id); ?></td>
                    <td><?php echo e($movement->id_article->code); ?></td>
                    <td><?php echo e($movement->id_article->name); ?></td>
                    <td><?php echo e($movement->id_article->unitName); ?></td>
                    <td><?php echo e($movement->id_article->type); ?></td>
                    <td><input type="number" name="<?php echo e($movement->id_article->id); ?>[quantity]"
                            value="<?php echo e($movement->quantity); ?>"></td>
                    <td><?php echo e($movement->stock->quantity); ?></td>
                    <td class="text-center">
                        <input type="hidden" name="<?php echo e($movement->id_article->id); ?>[id]" value="<?php echo e($movement->id); ?>">
                        <input class="id_article" type="hidden" name="<?php echo e($movement->id_article->id); ?>[id_article]"
                            value="<?php echo e($movement->id_article->id); ?>">
                        <input class="expandCheckbox" type="checkbox" name="<?php echo e($movement->id_article->id); ?>[delete]">
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>
<br>
<button class="btn btn-dark article-btn m-2" type="button" data-bs-toggle="collapse" data-bs-target="#article-t"
    aria-expanded="true" aria-controls="article-t">
    Agregar articulos</button>
<br>
<input class="btn btn-success m-2" type="submit" value="<?php echo e($modo); ?> Datos">

<div class="fixed-top aticle-container collapse" id="article-t">
    <div class="article-store">
        <div class="article-tittle d-flex gap-2 flex-column">

            <button class="btn btn-dark article-btn" type="button" data-bs-toggle="collapse"
                data-bs-target="#article-t" aria-expanded="true" aria-controls="article-t">X</button>

            <div class="filters" style="max-height: 160px">
                <h3 class="text-center">Seleccionar Articulos</h3>
                <p class="m-0 filter">Filtros:</p>
                <div class="row align-items-center border border-secondary p-2 mb-2 rounded">
                    <div class="col-auto">
                        <label for="codeTx">Codigo:</label>
                        <input class="form-control" type="text" maxlength="40"
                            value="<?php echo e(isset($codeTx) ? $codeTx : old('codeTx')); ?>" id="codeTx">
                    </div>
                    <div class="col-auto">
                        <label for="nameTx">Nombre:</label>
                        <input class="form-control" type="text" maxlength="40"
                            value="<?php echo e(isset($nameTx) ? $nameTx : old('nameTx')); ?>" id="nameTx">
                    </div>
                    <div class="col-auto">
                        <label for="typeTx">Tipo:</label>
                        <input class="form-control" type="text" maxlength="40"
                            value="<?php echo e(isset($typeTx) ? $typeTx : old('typeTx')); ?>" id="typeTx">
                    </div>
                    <div class="col-auto">
                        <button class="btn btn-primary md-block" id="filter-b">Buscar</button>
                    </div>
                </div>
            </div>

            <div class="article-scroll flex-grow-1">
                <table id="article-t" class="table table-striped table-hover table-md" width="100%">
                    <thead>
                        <tr>
                            <th class="table-light">#</th>
                            <th class="table-light">Codigo</th>
                            <th class="table-light">Nombre</th>
                            <th class="table-light">Unidad</th>
                            <th class="table-light">Tipo</th>
                            <th class="table-light">En Stock</th>
                            <th class="table-light text-center">Agregar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($article->id); ?></td>
                                <td><?php echo e($article->code); ?></td>
                                <td><?php echo e($article->name); ?></td>
                                <td><?php echo e($article->unitName); ?></td>
                                <td><?php echo e($article->type); ?></td>
                                <td><?php echo e(isset($article->stock->quantity) ? $article->stock->quantity : '-'); ?></td>
                                <td class="text-center">
                                    <input class="expandCheckbox" type="checkbox" name="article"
                                        value="<?php echo e($article->id); ?>"
                                        data-stock="<?php echo e(isset($article->stock->quantity) ? $article->stock->quantity : '-'); ?>">

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
            <div class="article-buttom">
                <button class="btn btn-success md-block" type="button" data-bs-toggle="collapse"
                    data-bs-target="#article-t" aria-expanded="true" aria-controls="article-t" id="insert">
                    Ingresar</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/functions/movement.js']); ?>
    <script>
        let route = "<?php echo e(url('api/article')); ?>";
        let refer = <?php echo e($id_refer); ?>;
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\movement\form.blade.php ENDPATH**/ ?>