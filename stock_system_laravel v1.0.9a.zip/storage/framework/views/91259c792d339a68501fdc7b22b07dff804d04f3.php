<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Centro de Stock</th>
            <th>Codigo</th>
            <th>Articulo</th>
            <th>Unidad</th>
            <th>Tipo</th>
            <th>Cantidad</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($stock->id); ?></td>
                <td><?php echo e($stock->StockCenter->name); ?></td>
                <td><?php echo e($stock->Article->code); ?></td>
                <td><?php echo e($stock->Article->name); ?></td>
                <td><?php echo e($stock->Article->UnitName); ?></td>
                <td><?php echo e($stock->Article->type); ?></td>
                <td><?php echo e($stock->quantity); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\exports\stocks.blade.php ENDPATH**/ ?>