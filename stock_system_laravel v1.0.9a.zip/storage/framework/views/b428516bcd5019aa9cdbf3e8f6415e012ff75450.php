

<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php echo $__env->make('layouts/alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex justify-content-between">
            <div class="flex-grow-1">
                <h3 class="text-center">Detalle Remito</h3>
                <p><?php echo e($refer->id); ?></p>
                <div class="form-group">
                    <label for="code">Origen:</label>
                    <p><?php echo e($refer->nameOrigin); ?></p>
                </div>
                <div class="form-group">
                    <label for="name">Destino:</label>
                    <p><?php echo e($refer->nameDestiny); ?></p>
                </div>
                <div class="form-group">
                    <label for="code">Estatus:</label>
                    <p><?php echo e($refer->statusName); ?></p>
                </div>
                <div class="form-group">
                    <label for="unit">Creado por:</label>
                    <p><?php echo e($refer->fullNameUser); ?></p>
                </div>
                <div class="form-group">
                    <label for="type">Creado:</label>
                    <p><?php echo e($refer->created_at); ?></p>
                </div>
                <div class="form-group">
                    <label for="type">Finalizado:</label>
                    <p><?php echo e($refer->date_ended); ?></p>
                </div>
                <div class="form-group">
                    <label for="telephone">Ultima Actualizacion:</label>
                    <p><?php echo e($refer->updated_at); ?></p>
                </div>
                <br>
                <?php if($refer->status == 'I'): ?>
                    <a class="btn btn-primary me-1" href="<?php echo e(url('refer/' . $refer->id . '/edit')); ?>">Emitir</a>
                <?php endif; ?>
                <?php if($refer->status == 'I' || $refer->status == 'E'): ?>
                    <a class="btn btn-warning me-1" href="<?php echo e(url('refer/' . $refer->id . '/edit')); ?>">Editar</a>
                    <form class="d-inline" action="<?php echo e(url('/refer/finalized/' . $refer->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PATCH')); ?>

                        <input class="btn btn-success me-1" type="submit"
                            onclick="return confirm('¿Finalizar remito?')" value="Finalizar">
                    </form>
                    <form class="d-inline" action="<?php echo e(url('/refer/' . $refer->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('DELETE')); ?>

                        <input class="btn btn-danger me-1" type="submit" onclick="return confirm('¿Cancelar remito?')" value="Cancelar">
                    </form>
                <?php endif; ?>
                <a class="btn btn-secondary" href="<?php echo e(url('refer/')); ?>">Regresar</a>
            </div>
            <div class="d-flex flex-column w-50">
                <h3 class="text-center">Articulos</h3>
                <div class="flex-grow-1 bg-secondary p-2 align-self-stretch">
                    <table class="table table-striped table-hover table-md bg-light align-items-stretch" id="movement-t">
                        <thead>
                            <tr>
                                <th class="table-light">Codigo</th>
                                <th class="table-light">Nombre</th>
                                <th class="table-light">Cantidad</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($movements)): ?>
                                <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($movement->Article->code); ?></td>
                                        <td><?php echo e($movement->Article->name); ?></td>
                                        <td><?php echo e($movement->quantity); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                </div>
                <div>
                    <?php echo $movements->links('vendor.pagination.bootstrap-5'); ?>

                    <?php if($refer->status == 'I' || $refer->status == 'E'): ?>
                    <a class="btn btn-warning me-2" href="<?php echo e(url('movement/create/' . $refer->id )); ?>">Editar Articulos</a>
                <?php endif; ?>
                <a class="btn btn-secondary" href="<?php echo e(url('movement/show/' . $refer->id )); ?>">Ver Articulos</a>
                </div>
                
            </div>

        </div>

        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\refer\show.blade.php ENDPATH**/ ?>