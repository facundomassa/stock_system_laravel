

<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(url('/article/' . $article->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PATCH')); ?>

            <?php echo $__env->make('article.form', ['modo' => 'Actualizar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\article\edit.blade.php ENDPATH**/ ?>