

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('layouts/alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form action="<?php echo e(url('/stock/')); ?>" method="get">
            <p class="m-0 filter">Filtros:</p>
            <div class="row align-items-center border border-secondary p-2 mb-2 rounded">
                <div class="col-auto">
                    <label for="stockselect">Centro de Stock:</label>
                    <select required class="form-control" name="stockselect" maxlength="60" id="stockselect"
                        onchange="this.form.submit()">
                        <option selected value="*">-Todos-</option>
                        <?php $__currentLoopData = $stockcenters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stockcenter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($stockselect == $stockcenter->id): ?>
                                <option selected value="<?php echo e($stockcenter->id); ?>"> <?php echo e($stockcenter->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($stockcenter->id); ?>"> <?php echo e($stockcenter->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-auto">
                    <label for="code">Codigo:</label>
                    <input class="form-control" type="text" name="code" maxlength="40"
                        value="<?php echo e(isset($code) ? $code : old('code')); ?>" id="code" onchange="this.form.submit()">
                </div>
                <div class="col-auto">
                    <label for="articlename">Articulo:</label>
                    <input class="form-control" type="text" name="articlename" maxlength="40"
                        value="<?php echo e(isset($articlename) ? $articlename : old('articlename')); ?>" id="articlename"
                        onchange="this.form.submit()">
                </div>
                <div class="col-auto">
                    <label for="type">Tipo:</label>
                    <input class="form-control" type="text" name="type" maxlength="40"
                        value="<?php echo e(isset($type) ? $type : old('type')); ?>" id="type" onchange="this.form.submit()">
                </div>
            </div>
        </form>
        <table class="table table-striped table-hover table-md">
            <thead>
                <tr>
                    <th class="table-light">#</th>
                    <th class="table-light">Centro de Stock</th>
                    <th class="table-light">Codigo</th>
                    <th class="table-light">Articulo</th>
                    <th class="taable-light">Unidad</th>
                    <th class="table-light">Tipo</th>
                    <th class="table-light">Cantidad</th>
                    <th class="tble-light">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($stock->id); ?></td>
                        <td><?php echo e($stock->StockCenter->name); ?></td>
                        <td><?php echo e($stock->Article->code); ?></td>
                        <td><?php echo e($stock->Article->name); ?></td>
                        <td><?php echo e($stock->Article->UnitName); ?></td>
                        <td><?php echo e($stock->Article->type); ?></td>
                        <td><?php echo e($stock->quantity); ?></td>
                        <td>
                            <a class="btn btn-outline-dark py-0" href="<?php echo e(url('/stock/' . $stock->id)); ?>"><i
                                    class="bi bi-eye-fill"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        <?php echo $stocks->appends(['stockselect' => $stockselect, 'code' => $code, 'articlename' => $articlename, 'type' => $type])->links('vendor.pagination.bootstrap-5'); ?>

        <a class="btn btn-primary py-0 " href="<?php echo e(url('stock/pdf?stockselect='.$stockselect.'&code='.$code.'&articlename='.$articlename.'&type='.$type)); ?>">Generar PDF</a>
        <a class="btn btn-primary py-0 " href="<?php echo e(url('stock/excel?stockselect='.$stockselect.'&code='.$code.'&articlename='.$articlename.'&type='.$type)); ?>">Generar Excel</a>
        <div class="fixed-top aticle-container collapse" id="article-t">
            <div class="article-store">
                <div class="article-tittle d-flex gap-2 flex-column">
                    <button class="btn btn-dark article-btn" type="button" data-bs-toggle="collapse"
                        data-bs-target="#article-t" aria-expanded="true" aria-controls="article-t">X</button>
                        <iframe id="framepdf" height="100%" class="frame" src="" frameborder="0"></iframe>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/ajax/generatepdf.js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\stock\index.blade.php ENDPATH**/ ?>