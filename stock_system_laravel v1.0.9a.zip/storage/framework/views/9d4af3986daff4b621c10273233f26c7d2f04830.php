<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="form-group">
    <label for="name">Nombre:</label>
    <input class="form-control" type="text" name="name"
        value="<?php echo e(isset($person->name) ? $person->name : old('name')); ?>" id="name">
</div>
<div class="form-group">
    <label for="surname">Apellido:</label>
    <input class="form-control" type="text" name="surname"
        value="<?php echo e(isset($person->surname) ? $person->surname : old('surname')); ?>" id="surname">
</div>
<div class="form-group">
    <label for="email">Correo:</label>
    <input class="form-control" type="email" name="email"
        value="<?php echo e(isset($person->email) ? $person->email : old('email')); ?>" id="email">
</div>
<div class="form-group">
    <label for="cuit">CUIT:</label>
    <input class="form-control" type="number" name="cuit"
        value="<?php echo e(isset($person->cuit) ? $person->cuit : old('cuit')); ?>" id="cuit">
</div>
<div class="form-group">
    <label for="telephone">Numero de Telefono:</label>
    <input class="form-control" type="number" name="telephone"
        value="<?php echo e(isset($person->telephone) ? $person->telephone : old('telephone')); ?>" id="telephone">
</div>
<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> Datos">
<a class="btn btn-primary" href="<?php echo e(url('person/')); ?>">Regresar</a>
<?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\person\form.blade.php ENDPATH**/ ?>