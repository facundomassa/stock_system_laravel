

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('layouts/alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table class="table table-striped table-hover table-md">
            <thead>
                <tr>
                    <th class="table-light">#</th>
                    <th class="table-light">Nombre</th>
                    <th class="table-light">Correo</th>
                    <th class="table-light">Cuit</th>
                    <th class="table-light">Telefono</th>
                    <th class="table-light">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($person->id); ?></td>
                        <td><?php echo e($person->fullName); ?></td>
                        <td><?php echo e($person->email); ?></td>
                        <td><?php echo e($person->cuit); ?></td>
                        <td><?php echo e($person->telephone); ?></td>
                        <td>
                            <a class="btn btn-warning py-0" href="<?php echo e(url('/person/' . $person->id . '/edit')); ?>">Editar</a>

                            <form class="d-inline" action="<?php echo e(url('/person/' . $person->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('DELETE')); ?>

                                <input class="btn btn-danger py-0" type="submit" onclick="return confirm('¿Quieres borrar?')"
                                    value="Borrar">
                            </form>
                            <a class="btn btn-outline-dark py-0" href="<?php echo e(url('/person/' . $person->id)); ?>"><i class="bi bi-eye-fill"></i></a>
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        <?php echo $persons->links('vendor.pagination.bootstrap-5'); ?>

        <a class="btn btn-success" href="<?php echo e(url('/person/create')); ?>">Nuevo ingreso</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\Person\index.blade.php ENDPATH**/ ?>