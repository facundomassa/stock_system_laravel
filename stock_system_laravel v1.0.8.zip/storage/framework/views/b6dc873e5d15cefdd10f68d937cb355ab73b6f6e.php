<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="form-group">
    <label for="name">Nombre:</label>
    <input required class="form-control" type="text" name="name" maxlength="60"
        value="<?php echo e(isset($article->name) ? $article->name : old('name')); ?>" id="name">
</div>
<div class="form-group">
    <label for="code">Codigo:</label>
    <input class="form-control" type="text" name="code" maxlength="16"
        value="<?php echo e(isset($article->code) ? $article->code : old('code')); ?>" id="code">
</div>
<div class="form-group">
    <label for="unit">Unidad:</label>
    <select required class="form-control" name="unit" id="unit">
        <option disabled selected value="">-Seleccionar una opcion-</option>
        <option <?php echo e((isset($article->unit) ? $article->unit : old('unit')) == "U" ? "selected" : ""); ?> value="U"> Unidad</option>
        <option <?php echo e((isset($article->unit) ? $article->unit : old('unit')) == "M" ? "selected" : ""); ?> value="M"> Metro</option>
        <option <?php echo e((isset($article->unit) ? $article->unit : old('unit')) == "K" ? "selected" : ""); ?> value="K"> Kilogramo</option>
    </select>
</div>
<div class="form-group">
    <label for="type">Tipo:</label>
    <input class="form-control" type="text" name="type" maxlength="30"
        value="<?php echo e(isset($article->type) ? $article->type : old('type')); ?>" id="type">
</div>
<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> Datos">
<a class="btn btn-primary" href="<?php echo e(url('article/')); ?>">Regresar</a>
<?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\Article\form.blade.php ENDPATH**/ ?>