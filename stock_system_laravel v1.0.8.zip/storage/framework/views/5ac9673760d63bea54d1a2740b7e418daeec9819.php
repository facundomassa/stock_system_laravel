

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('layouts/alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table class="table table-striped table-hover table-md" >
            <thead >
                <tr>
                    <th class="table-light">#</th>
                    <th class="table-light">Pais</th>
                    <th class="table-light">Provincia</th>
                    <th class="table-light">Ciudad</th>
                    <th class="table-light">Localidad</th>
                    <th class="table-light">Calle</th>
                    <th class="table-light">Numero</th>
                    <th class="table-light">Dpto</th>
                    <th class="table-light">Casa</th>
                    <th class="table-light">Piso</th>
                    <th class="table-light">CP</th>
                    <th class="table-light">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($direction->id); ?></td>
                        <td><?php echo e($direction->country); ?></td>
                        <td><?php echo e($direction->state); ?></td>
                        <td><?php echo e($direction->city); ?></td>
                        <td><?php echo e($direction->locality); ?></td>
                        <td><?php echo e($direction->street); ?></td>
                        <td><?php echo e($direction->number); ?></td>
                        <td><?php echo e($direction->deparment); ?></td>
                        <td><?php echo e($direction->house); ?></td>
                        <td><?php echo e($direction->floor); ?></td>
                        <td><?php echo e($direction->cp); ?></td>
                        <td>
                            <a class="btn btn-warning py-0" href="<?php echo e(url('/direction/' . $direction->id . '/edit')); ?>">Editar</a>

                            <form class="d-inline" action="<?php echo e(url('/direction/' . $direction->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('DELETE')); ?>

                                <input class="btn btn-danger py-0" type="submit" onclick="return confirm('¿Quieres borrar?')"
                                    value="Borrar">
                            </form>
                            <a class="btn btn-outline-dark py-0" href="<?php echo e(url('/direction/' . $direction->id)); ?>"><i class="bi bi-eye-fill"></i></a>
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        <?php echo $directions->links('vendor.pagination.bootstrap-5'); ?>

        <a class="btn btn-success" href="<?php echo e(url('/direction/create')); ?>">Nuevo ingreso</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\Direction\index.blade.php ENDPATH**/ ?>