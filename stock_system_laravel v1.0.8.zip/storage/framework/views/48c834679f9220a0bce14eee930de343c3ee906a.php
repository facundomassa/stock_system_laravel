

<?php $__env->startSection('content'); ?>
    <div class="container">
        <p><?php echo e($article->id); ?></p>
        <div class="form-group">
            <label for="name">Nombre:</label>
            <p><?php echo e($article->name); ?></p>
        </div>
        <div class="form-group">
            <label for="code">Codigo:</label>
            <p><?php echo e($article->code); ?></p>
        </div>
        <div class="form-group">
            <label for="unit">Unidad:</label>
            <p><?php echo e($article->unitName); ?></p>
        </div>
        <div class="form-group">
            <label for="type">Tipo:</label>
            <p><?php echo e($article->type); ?></p>
        </div>
        <div class="form-group">
            <label for="telephone">Ultima Actualizacion:</label>
            <p><?php echo e($article->updated_at); ?></p>
        </div>
        <br>
        <a class="btn btn-success" href="<?php echo e(url('article/' . $article->id . '/edit')); ?>">Editar</a>
        <a class="btn btn-primary" href="<?php echo e(url('article/')); ?>">Regresar</a>
        <form class="d-inline" action="<?php echo e(url('/article/' . $article->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

            <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')"
                value="Borrar">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\Article\show.blade.php ENDPATH**/ ?>