

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('layouts/alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          
        <table class="table table-striped table-hover table-md">
            <thead>
                <tr>
                    <th class="table-light">#</th>
                    <th class="table-light">Origen</th>
                    <th class="table-light">Destino</th>
                    <th class="table-light">Fecha Creado</th>
                    <th class="table-light">Fecha Finalizado</th>
                    <th class="table-light">Creado por</th>
                    <th class="table-light">Estaus</th>
                    <th class="table-light">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $refers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($refer->id); ?></td>
                        <td><?php echo e($refer->nameOrigin); ?></td>
                        <td><?php echo e($refer->nameDestiny); ?></td>
                        <td><?php echo e($refer->created_at_formatted); ?></td>
                        <td><?php echo e($refer->dateEndedFormatted); ?></td>
                        <td><?php echo e($refer->fullNameUser); ?></td>
                        <td><?php echo e($refer->statusName); ?></td>
                        <td>
                            <?php if($refer->status == 'I'): ?>
                                <a class="btn btn-primary py-0 " href="<?php echo e(url('refer/emited/' . $refer->id)); ?>">Emitir</a>
                            <?php endif; ?>
                            <?php if($refer->status == 'I' || $refer->status == 'E'): ?>
                                <a class="btn btn-warning py-0"
                                    href="<?php echo e(url('/refer/' . $refer->id . '/edit')); ?>">Editar</a>
                                <form class="d-inline" action="<?php echo e(url('/refer/finalized/' . $refer->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('PATCH')); ?>

                                    <input class="btn btn-success py-0" type="submit"
                                        onclick="return confirm('¿Finalizar remito?')" value="Finalizar">
                                </form>
                                <form class="d-inline" action="<?php echo e(url('/refer/' . $refer->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('DELETE')); ?>

                                    <input class="btn btn-danger py-0" type="submit"
                                        onclick="return confirm('¿Cancelar remito?')" value="Cancelar">
                                </form>
                            <?php endif; ?>
                            <a class="btn btn-outline-dark py-0" href="<?php echo e(url('/refer/' . $refer->id)); ?>"><i
                                    class="bi bi-eye-fill"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        <?php echo $refers->links('vendor.pagination.bootstrap-5'); ?>

        <a class="btn btn-success" href="<?php echo e(url('/refer/create')); ?>">Nuevo ingreso</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\Refer\index.blade.php ENDPATH**/ ?>