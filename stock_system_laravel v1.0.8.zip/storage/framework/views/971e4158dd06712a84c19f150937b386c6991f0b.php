<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="form-group">
    <label for="country">Pais:</label>
    <select required class="form-control" name="country" maxlength="60" id="country">
        <option disabled selected value="">-Seleccionar una opcion-</option>
        <?php $__currentLoopData = $countrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if((isset($direction->country) ? $direction->country : old('country')) == $country['country_name']): ?>
                <option selected value="<?php echo e($country['country_name']); ?>"> <?php echo e($country['country_name']); ?></option>
            <?php else: ?>
                <option value="<?php echo e($country['country_name']); ?>"> <?php echo e($country['country_name']); ?></option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="form-group">
    <label for="state">Provincia:</label>
    <select required class="form-control" name="state" maxlength="60" id="state">
        <option disabled selected value="">-Seleccionar una opcion-</option>
        <?php if(isset($direction->country) ): ?>
                <option selected value="<?php echo e(isset($direction->state) ? $direction->state : old('state')); ?>"> <?php echo e(isset($direction->state) ? $direction->state : old('state')); ?></option>
        <?php endif; ?>
    </select>
</div>
<div class="form-group">
    <label for="city">Ciudad:</label>
    <input required class="form-control" type="text" name="city" maxlength="60"
        value="<?php echo e(isset($direction->city) ? $direction->city : old('city')); ?>" id="city">
</div>
<div class="form-group">
    <label for="locality">Localidad:</label>
    <input required class="form-control" type="text" name="locality" maxlength="100"
        value="<?php echo e(isset($direction->locality) ? $direction->locality : old('locality')); ?>" id="locality">
</div>
<div class="form-group">
    <label for="street">Calle:</label>
    <input required class="form-control" type="text" name="street" maxlength="100"
        value="<?php echo e(isset($direction->street) ? $direction->street : old('street')); ?>" id="street">
</div>
<div class="form-group">
    <label for="number">Numero:</label>
    <input required class="form-control" type="number" name="number" maxlength="11"
        value="<?php echo e(isset($direction->number) ? $direction->number : old('number')); ?>" id="number">
</div>
<div class="form-group">
    <label for="department">Departamento:</label>
    <input class="form-control" type="text" name="department" maxlength="6"
        value="<?php echo e(isset($direction->department) ? $direction->department : old('department')); ?>" id="department">
</div>
<div class="form-group">
    <label for="house">Casa:</label>
    <input class="form-control" type="text" name="house" maxlength="6"
        value="<?php echo e(isset($direction->house) ? $direction->house : old('house')); ?>" id="house">
</div>
<div class="form-group">
    <label for="floor">Piso:</label>
    <input class="form-control" type="text" name="floor" maxlength="4"
        value="<?php echo e(isset($direction->floor) ? $direction->floor : old('floor')); ?>" id="floor">
</div>
<div class="form-group">
    <label for="cp">Codigo Postal:</label>
    <input required class="form-control" type="number" name="cp" maxlength="11"
        value="<?php echo e(isset($direction->cp) ? $direction->cp : old('cp')); ?>" id="cp">
</div>
<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> Datos">
<a class="btn btn-primary" href="<?php echo e(url('direction/')); ?>">Regresar</a>

<?php $__env->startSection('js'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/ajax/state.js']); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\Direction\form.blade.php ENDPATH**/ ?>