<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="form-group">
    <label for="id_enterprise">Operacion:</label>
    <select required class="form-control" name="id_enterprise" id="id_enterprise">
        <option disabled selected value="">-Seleccionar una opcion-</option>
        <?php $__currentLoopData = $enterprises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enterprise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if((isset($stockcenter->id_enterprise) ? $stockcenter->id_enterprise : old('id_enterprise')) == $enterprise->id): ?>
                <option selected value="<?php echo e($enterprise->id); ?>"> <?php echo e($enterprise->name); ?></option>
            <?php else: ?>
                <option value="<?php echo e($enterprise->id); ?>"> <?php echo e($enterprise->name); ?></option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="form-group">
    <label for="name">Nombre:</label>
    <input required class="form-control" type="text" name="name" maxlength="60"
        value="<?php echo e(isset($stockcenter->name) ? $stockcenter->name : old('name')); ?>" id="name">
</div>
<div class="form-group">
    <label for="type">Tipo:</label>
    <select required class="form-control" name="type" id="type">
        <option disabled selected value="">-Seleccionar una opcion-</option>
        <option <?php echo e((isset($stockcenter->type) ? $stockcenter->type : old('type')) == "D" ? "selected" : ""); ?> value="D"> Deposito</option>
        <option <?php echo e((isset($stockcenter->type) ? $stockcenter->type : old('type')) == "M" ? "selected" : ""); ?> value="M"> Movil</option>
        <option <?php echo e((isset($stockcenter->type) ? $stockcenter->type : old('type')) == "T" ? "selected" : ""); ?> value="T"> Taller</option>
        <option <?php echo e((isset($stockcenter->type) ? $stockcenter->type : old('type')) == "C" ? "selected" : ""); ?> value="C"> Consumo</option>
        <option <?php echo e((isset($stockcenter->type) ? $stockcenter->type : old('type')) == "P" ? "selected" : ""); ?> value="P"> Proveedor</option>
    </select>
</div>
<div class="form-group">
    <label for="id_direction">Direccion:</label>
    <select class="form-control" name="id_direction" id="id_direction">
        <option disabled selected value="">-Seleccionar una opcion-</option>
        <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if((isset($stockcenter->id_direction) ? $stockcenter->id_direction : old('id_direction')) == $direction->id): ?>
                <option selected value="<?php echo e($direction->id); ?>"> <?php echo e($direction->street . $direction->number); ?></option>
            <?php else: ?>
                <option value="<?php echo e($direction->id); ?>"> <?php echo e($direction->street . $direction->number); ?></option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="form-group">
    <label for="id_person">Encargado:</label>
    <select class="form-control" name="id_person" id="id_person">
        <option disabled selected value="">-Seleccionar una opcion-</option>
        <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if((isset($stockcenter->id_person) ? $stockcenter->id_person : old('id_person')) == $person->id): ?>
                <option selected value="<?php echo e($person->id); ?>"> <?php echo e($person->name . ' ' . $person->surname); ?></option>
            <?php else: ?>
                <option value="<?php echo e($person->id); ?>"> <?php echo e($person->name . ' ' . $person->surname); ?></option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> Datos">
<a class="btn btn-primary" href="<?php echo e(url('stockcenter/')); ?>">Regresar</a>
<?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\StockCenter\form.blade.php ENDPATH**/ ?>