<footer class="bg-dark text-center text-white ">
    <div class="container d-flex justify-content-between">
        <div class="text-center p-3">
            © 2022 Copyright <span>version: <?php echo e(\Tremby\LaravelGitVersion\GitVersionHelper::getVersion()); ?></span>
        </div>
        <div class="text-center p-3">
            Created by: <strong>Facundo Massa</strong>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views/layouts/footer.blade.php ENDPATH**/ ?>