<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="form-group">
    <label for="name">Nombre:</label>
    <input required class="form-control" type="text" name="name" maxlength="60"
        value="<?php echo e(isset($enterprise->name) ? $enterprise->name : old('name')); ?>" id="name">
</div>
<br>
<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> Datos">
<a class="btn btn-primary" href="<?php echo e(url('enterprise/')); ?>">Regresar</a>
<?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\Enterprise\form.blade.php ENDPATH**/ ?>