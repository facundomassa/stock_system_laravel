

<?php $__env->startSection('content'); ?>
    <div class="container">
        <p><?php echo e($person->id); ?></p>
        <div class="form-group">
            <label for="name">Nombre:</label>
            <p><?php echo e($person->name); ?></p>
        </div>
        <div class="form-group">
            <label for="surname">Apellido:</label>
            <p><?php echo e($person->surname); ?></p>
        </div>
        <div class="form-group">
            <label for="email">Correo:</label>
            <p><?php echo e($person->email); ?></p>
        </div>
        <div class="form-group">
            <label for="cuit">CUIT:</label>
            <p><?php echo e($person->cuit); ?></p>
        </div>
        <div class="form-group">
            <label for="telephone">Numero de Telefono:</label>
            <p><?php echo e($person->telephone); ?></p>
        </div>
        <div class="form-group">
            <label for="telephone">Ultima Actualizacion:</label>
            <p><?php echo e($person->updated_at); ?></p>
        </div>
        <br>
        <a class="btn btn-success" href="<?php echo e(url('person/' . $person->id . '/edit')); ?>">Editar</a>
        <a class="btn btn-primary" href="<?php echo e(url('person/')); ?>">Regresar</a>
        <form class="d-inline" action="<?php echo e(url('/person/' . $person->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

            <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')"
                value="Borrar">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\Person\show.blade.php ENDPATH**/ ?>