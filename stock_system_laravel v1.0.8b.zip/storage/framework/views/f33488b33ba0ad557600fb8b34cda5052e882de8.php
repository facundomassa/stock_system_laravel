

<?php $__env->startSection('content'); ?>
    <div class="container">
        <p><?php echo e($enterprise->id); ?></p>
        <div class="form-group">
            <label for="name">Nombre:</label>
            <p><?php echo e($enterprise->name); ?></p>
        </div>
        <br>
        <a class="btn btn-success" href="<?php echo e(url('enterprise/' . $enterprise->id . '/edit')); ?>">Editar</a>
        <a class="btn btn-primary" href="<?php echo e(url('enterprise/')); ?>">Regresar</a>
        <form class="d-inline" action="<?php echo e(url('/enterprise/' . $enterprise->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

            <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')"
                value="Borrar">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stock_system_laravel\resources\views\Enterprise\show.blade.php ENDPATH**/ ?>